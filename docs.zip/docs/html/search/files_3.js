var searchData=
[
  ['local_5fparallelization_2ecpp_0',['local_parallelization.cpp',['../local__parallelization_8cpp.html',1,'']]]
];
