var searchData=
[
  ['heuristic_2ecpp_0',['heuristic.cpp',['../heuristic_8cpp.html',1,'']]]
];
