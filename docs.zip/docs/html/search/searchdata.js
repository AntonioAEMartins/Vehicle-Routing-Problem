var indexSectionsWithContent =
{
  0: "bfghlmnp",
  1: "g",
  2: "bghl",
  3: "fglmnp",
  4: "fghln"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

