var searchData=
[
  ['figsize_0',['figsize',['../namespacegraph.html#a1e67972edc04459c571ba07d1dcb27a2',1,'graph']]]
];
